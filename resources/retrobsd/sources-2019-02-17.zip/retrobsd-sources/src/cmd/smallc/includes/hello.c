main()
{
    printf("hello\n");
}
