exit(retcode) int retcode; {
#asm
        jmp     0
#endasm
}

