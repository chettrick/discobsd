void hello()
{
    puts ("Hello, World!\n");
}
