icache is a MIPS emulator + software instruction cache.

With it one may be able to run large programs on MIPS32 processors
that would otherwise not fit into small on-chip RAMs of ~128KB.

Supported platform: RetroBSD.
http://www.retrobsd.org/

See the Wiki for more up-to-date details:
http://github.com/alexfru/icacheMips/wiki
