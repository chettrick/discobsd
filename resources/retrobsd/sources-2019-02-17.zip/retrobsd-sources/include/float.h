#ifndef _FLOAT_H_
#define _FLOAT_H_

#include <machine/float.h>

#endif /* _FLOAT_H_ */
