#ifndef _UTIL_H
#define _UTIL_H

#include <string>

using namespace std;

extern void replace_all(string &haystack, string from, string to);
extern void uc(string &s);

#endif
