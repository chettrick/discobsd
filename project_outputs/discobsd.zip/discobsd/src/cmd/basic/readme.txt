This is a version of Basic adapted for RetroBSD.

It is based on Micro-Basic from Dave Dunfield:
* Copyright 1982-2000 Dave Dunfield
* All rights reserved.
* Permission granted for personal (non-commercial) use only.

How to build:
- From command prompt type: "make"

Archive contents:
- BASIC.C = original Mikro-C source code
- README.TXT = this file
- BLKJACK.BAS = example does work
- HILOW.BAS = example works ok
- Makefile = Makefile
- RENUMBER.C = RENUMBER source code
___
Best wishes,
Serge Vakulenko <serge@vak.ru>
